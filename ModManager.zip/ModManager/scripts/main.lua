-- ModManager for Light Up The Town (UE4SS Lua mod)
local Config = require("mm_config")
local Manifest = require("mm_manifest")
local Ui = require("mm_ui")

local SRC = debug.getinfo(1, "S").source
local srcPath = SRC:gsub("^@", ""):gsub("\\", "/")
-- .../<mod folder>/<scripts folder>/main.lua  ->  .../<mod folder>   (works whatever case "scripts" has)
local MOD_DIR = srcPath:match("^(.*)/[^/]+/[^/]+$")
local MOD_FOLDER = MOD_DIR and MOD_DIR:match("([^/]+)$") or "ModManager"

local logStarted = false
local function Log(msg)
  print("[ModManager] " .. tostring(msg) .. "\n")
  if MOD_DIR then
    local f = io.open(MOD_DIR .. "/modmanager_log.txt", logStarted and "a" or "w")
    if f then logStarted = true; f:write(os.date("%H:%M:%S ") .. tostring(msg) .. "\n"); f:close() end
  end
end

Ui.init(Config, Log)

-- Crash trace: the last stage written here tells us whether a crash happened inside our code.
-- "<stage> start" with no "<stage> end" after it means the game died while we were running.
local function Trace(stage)
  if not Config.TRACE then return end
  local f = io.open(MOD_DIR .. "/modmanager_trace.txt", "w")
  if f then f:write(os.date("%H:%M:%S ") .. stage .. "\n"); f:close() end
end

-- Mods folder -> node tree -------------------------------------------------------------
local function fromIterate(t, name)
  local node = { name = t.__name or name, path = t.__absolute_path, dirs = {}, files = {} }
  local files = t.__files
  if type(files) == "table" then
    for _, f in pairs(files) do
      if type(f) == "table" then
        node.files[#node.files + 1] = { name = f.__name, path = f.__absolute_path }
      elseif type(f) == "string" then
        node.files[#node.files + 1] = { name = f, path = (node.path or "") .. "\\" .. f }
      end
    end
  end
  for k, v in pairs(t) do
    if type(k) == "string" and k:sub(1, 2) ~= "__" and type(v) == "table" then node.dirs[k] = fromIterate(v, k) end
  end
  return node
end

local function findModsNode(tree)
  -- a folder named "Mods" that contains this mod (found by its scripts\\mm_ui.lua, so the folder can be named anything)
  local function isSelf(d)
    for k, sd in pairs(d.dirs) do
      if k:lower() == "scripts" then
        for _, f in ipairs(sd.files) do if f.name and f.name:lower() == "mm_ui.lua" then return true end end
      end
    end
  end
  local function walk(node, depth)
    if depth > 8 then return nil end
    if node.name and node.name:lower() == "mods" then
      for k, d in pairs(node.dirs) do
        if isSelf(d) then
          MOD_FOLDER = k
          if not MOD_DIR and d.path then MOD_DIR = (d.path:gsub("\\", "/")) end
          return node
        end
      end
    end
    for _, d in pairs(node.dirs) do
      local r = walk(d, depth + 1)
      if r then return r end
    end
  end
  return walk(tree, 0)
end

-- fallback when IterateGameDirectories is unavailable: ask Windows for a directory listing
local function listCmd(path, flag)
  local p = io.popen('dir /b ' .. flag .. ' "' .. path .. '" 2>nul')
  if not p then return {} end
  local out = {}
  for line in p:lines() do if line ~= "" then out[#out + 1] = line end end
  p:close()
  return out
end

local function fromDisk(path, name, depth)
  local node = { name = name, path = path, dirs = {}, files = {} }
  for _, f in ipairs(listCmd(path, "/a-d")) do node.files[#node.files + 1] = { name = f, path = path .. "\\" .. f } end
  if depth > 0 then
    for _, d in ipairs(listCmd(path, "/ad")) do node.dirs[d] = fromDisk(path .. "\\" .. d, d, depth - 1) end
  end
  return node
end

local function scanMods()
  local root
  if IterateGameDirectories then
    local ok, tree = pcall(IterateGameDirectories)
    if ok and tree then
      root = findModsNode({ name = "root", dirs = { Game = fromIterate(tree.Game, "Game") }, files = {} })
    end
  end
  if not root and MOD_DIR then
    local parent = MOD_DIR:match("^(.*)[/\\][^/\\]+$")
    if parent then root = fromDisk(parent, "Mods", 2) end
  end
  if not root then
    Log("Couldn't locate the Mods folder.")
    return {}
  end
  local mods = Manifest.scan(root, Config, MOD_FOLDER)
  Log("Found " .. #mods .. " mod(s) with info files in " .. tostring(root.path))
  return mods
end

-- find our own folder early so the log/dump files land next to the mod
if not MOD_DIR and IterateGameDirectories then
  pcall(function()
    local tree = IterateGameDirectories()
    findModsNode({ name = "root", dirs = { Game = fromIterate(tree.Game, "Game") }, files = {} })
  end)
end

-- Wiring ------------------------------------------------------------------------------
Ui.onMods = function()
  local ok, err = pcall(function() Ui.open(scanMods()) end)
  if not ok then Log("Opening the manager failed: " .. tostring(err)) end
end

Ui.onReload = scanMods

Ui.onToggle = function(mod)
  local ok, err = Manifest.set_enabled(mod, not mod.enabled)
  if ok then
    mod.toggle_error = nil
    Log(mod.folder .. " is now " .. (mod.enabled and "enabled" or "disabled") .. " (applies on next start)")
  else
    mod.toggle_error = tostring(err)
    Log("Couldn't change " .. mod.folder .. ": " .. tostring(err))
  end
end

local function toggle()
  if Ui.isOpen() then Ui.close()
  elseif Ui.hasMenu() then Ui.onMods() end
end

-- keep the menu button alive
LoopAsync(Config.POLL_MS, function()
  ExecuteInGameThread(function()
    Trace("ensureButton start")
    local ok, err = pcall(Ui.ensureButton)
    Trace("ensureButton end")
    if not ok then Log("ensureButton: " .. tostring(err)) end
  end)
  return false
end)

-- pause menu button (checked often so it is there as soon as the menu opens)
LoopAsync(400, function()
  ExecuteInGameThread(function()
    Trace("ensurePause start")
    local ok, err = pcall(Ui.ensurePause)
    Trace("ensurePause end")
    if not ok then Log("ensurePause: " .. tostring(err)) end
  end)
  return false
end)

-- hover highlight
LoopAsync(60, function()
  ExecuteInGameThread(function() Trace("hoverTick start"); pcall(Ui.hoverTick); Trace("hoverTick end") end)
  return false
end)

local function key(name, fallback) return (Key and Key[name]) or fallback end

RegisterKeyBind(key("LEFT_MOUSE_BUTTON", 0x01), function()
  ExecuteInGameThread(function() pcall(Ui.click) end)
end)
RegisterKeyBind(key(Config.KEY_TOGGLE, 0x77), function() ExecuteInGameThread(toggle) end)
RegisterKeyBind(key("ESCAPE", 0x1B), function()
  ExecuteInGameThread(function() if Ui.isOpen() then Ui.close() end end)
end)
RegisterKeyBind(key("DOWN_ARROW", 0x28), function() ExecuteInGameThread(function() Ui.scroll(160) end) end)
RegisterKeyBind(key("UP_ARROW", 0x26), function() ExecuteInGameThread(function() Ui.scroll(-160) end) end)
RegisterKeyBind(key(Config.KEY_DUMP, 0x76), function()
  ExecuteInGameThread(function()
    local ok, err = pcall(Ui.dump, (MOD_DIR or ".") .. "/menu_dump.txt")
    if not ok then Log("dump failed: " .. tostring(err)) end
  end)
end)

Log("build: pause-button v11 (path handles), mod folder = " .. tostring(MOD_DIR))
Log("Loaded. The 'mods' button appears on the main menu (" .. Config.KEY_TOGGLE .. " also opens it).")
