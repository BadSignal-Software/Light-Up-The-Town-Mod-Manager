-- Finds modmanager.json / modmanager.txt in every mod folder and turns them into plain records.
--
-- A "node" is { name=, path=, dirs={ name = node }, files={ {name=, path=}, ... } }.
-- main.lua builds that tree from UE4SS's IterateGameDirectories (or a dir fallback);
-- the tests build it from the real disk.
local Json = require("mm_json")

local M = {}
M.read_file = function(path)
  local f = io.open(path, "rb")
  if not f then return nil end
  local s = f:read("a")
  f:close()
  return s
end

local IMG_EXT = { png = true, jpg = true, jpeg = true, bmp = true }

local function trim(s) return (s:gsub("^%s+", ""):gsub("%s+$", "")) end
local function lower(s) return tostring(s):lower() end
local function ext(name) return lower(name:match("%.([^.]+)$") or "") end
local function stem(name) return (name:gsub("%.[^.]+$", "")) end
local function basename(p) return (tostring(p):match("([^/\\]+)$")) or tostring(p) end

local function normkey(k)
  k = lower(trim(k)):gsub("[%s%-]+", "_")
  return (k:gsub("^_+", ""):gsub("_+$", ""))
end

local ALIASES = {
  title = "name", mod_name = "name", modname = "name",
  authors = "author", creator = "author", by = "author", made_by = "author",
  desc = "description", summary = "description", short_description = "description", tagline = "description",
  about = "long_description", details = "long_description", longdescription = "long_description",
  long_desc = "long_description", full_description = "long_description",
  url = "website", link = "website", homepage = "website", site = "website",
  categories = "tags", category = "tags", keywords = "tags",
  requires = "dependencies", deps = "dependencies", requirements = "dependencies",
  gameversion = "game_version", supported_game_version = "game_version",
  screenshots = "images", image = "images", pictures = "images", gallery = "images",
  thumbnail = "icon", logo = "icon",
}
local LIST_KEYS = { tags = true, dependencies = true }

local function as_list(v)
  if v == nil then return {} end
  if type(v) == "table" then
    local out = {}
    for _, x in ipairs(v) do out[#out + 1] = tostring(x) end
    return out
  end
  local out = {}
  for part in tostring(v):gmatch("[^,;\n]+") do
    part = trim(part)
    if part ~= "" then out[#out + 1] = part end
  end
  return out
end

-- Turns any decoded value into display text.
local function show(v, depth)
  depth = depth or 0
  local t = type(v)
  if t == "table" then
    local parts = {}
    local keys = Json.order[v]
    if keys then
      for _, k in ipairs(keys) do parts[#parts + 1] = k .. ": " .. show(v[k], depth + 1) end
      return table.concat(parts, depth == 0 and "\n" or "; ")
    end
    for _, x in ipairs(v) do parts[#parts + 1] = show(x, depth + 1) end
    return table.concat(parts, ", ")
  elseif t == "boolean" then
    return v and "yes" or "no"
  end
  return tostring(v)
end

-- modmanager.txt: "key: value" lines. Indented / key-less lines continue the previous value.
-- Lines starting with # are comments. images: "file.png | caption" separated by ; or new lines
-- (or repeat an `image:` line per picture).
local function parse_txt(text)
  if text:sub(1, 3) == "\239\187\191" then text = text:sub(4) end
  local obj, keys = {}, {}
  Json.order[obj] = keys
  local cur
  for line in (text .. "\n"):gmatch("(.-)\r?\n") do
    if line:match("^%s*#") then
      -- comment
    else
      local k, v = line:match("^([%a][%w _%-]*)%s*[:=]%s*(.-)%s*$")
      if k then
        cur = normkey(k)
        cur = ALIASES[cur] or cur
        if obj[cur] == nil then keys[#keys + 1] = cur; obj[cur] = v
        else obj[cur] = obj[cur] .. "\n" .. v end
      elseif cur and trim(line) ~= "" then
        obj[cur] = (obj[cur] ~= "" and (obj[cur] .. "\n") or "") .. trim(line)
      elseif cur and trim(line) == "" then
        obj[cur] = obj[cur] .. "\n"
      end
    end
  end
  for _, k in ipairs(keys) do obj[k] = (obj[k]:gsub("%s+$", "")) end
  return obj
end

-- read_dims: (path) -> w, h from the file header (png / jpg / bmp)
local function read_dims(path)
  local f = io.open(path, "rb")
  if not f then return nil end
  local head = f:read(524288) or ""
  local size = f:seek("end")
  f:close()
  local w, h
  if head:sub(1, 8) == "\137PNG\r\n\26\n" and #head >= 24 then
    w, h = string.unpack(">I4I4", head, 17)
  elseif head:sub(1, 2) == "BM" and #head >= 26 then
    w, h = string.unpack("<i4i4", head, 19)
    h = math.abs(h)
  elseif head:sub(1, 2) == "\255\216" then
    local i = 3
    while i < #head - 9 do
      if head:byte(i) ~= 0xFF then i = i + 1
      else
        local m = head:byte(i + 1)
        if m == 0xFF then i = i + 1
        elseif m >= 0xD0 and m <= 0xD9 or m == 0x01 then i = i + 2
        else
          local len = string.unpack(">I2", head, i + 2)
          if m >= 0xC0 and m <= 0xCF and m ~= 0xC4 and m ~= 0xC8 and m ~= 0xCC then
            h, w = string.unpack(">I2I2", head, i + 5)
            break
          end
          i = i + 2 + len
        end
      end
    end
  end
  return w, h, size
end
M.read_dims = read_dims

local function find_file(node, wanted)
  if not node then return nil end
  for _, f in ipairs(node.files) do
    if lower(f.name) == wanted then return f end
  end
end

local function find_dir(node, wanted)
  if not node then return nil end
  for k, d in pairs(node.dirs) do
    if lower(k) == wanted then return d end
  end
end

local function pretty(name)
  local s = stem(name):gsub("[_%-]+", " ")
  return trim(s)
end

-- entries -> list of { file=, title=, caption= } from a manifest `images` value or a sidecar file
local function image_entries(v)
  local out = {}
  if type(v) == "string" then
    for part in v:gmatch("[^;\n]+") do
      local file, cap = part:match("^%s*(.-)%s*|%s*(.-)%s*$")
      if not file then file = trim(part) end
      if file ~= "" then out[#out + 1] = { file = file, caption = cap ~= "" and cap or nil } end
    end
  elseif type(v) == "table" then
    local keys = Json.order[v]
    if keys then -- object: { "a.png": {..} | "caption" }  or a single entry object with .file
      if v.file then
        out[1] = { file = tostring(v.file), title = v.title or v.name, caption = v.caption or v.description or v.alt }
      else
        for _, k in ipairs(keys) do
          local e = v[k]
          if type(e) == "table" then
            out[#out + 1] = { file = k, title = e.title or e.name, caption = e.caption or e.description or e.alt }
          else
            out[#out + 1] = { file = k, caption = tostring(e) }
          end
        end
      end
    else
      for _, e in ipairs(v) do
        if type(e) == "string" then
          out[#out + 1] = { file = e }
        elseif type(e) == "table" and (e.file or e.path or e.name) then
          out[#out + 1] = { file = tostring(e.file or e.path or e.name), title = e.title,
                            caption = e.caption or e.description or e.alt }
        end
      end
    end
  end
  return out
end

local function read_manifest(mod, node, cfg)
  for _, wanted in ipairs(cfg.MANIFEST_NAMES) do
    local f = find_file(node, lower(wanted))
    if f then
      mod.source = f.name
      mod.format = ext(f.name) == "json" and "json" or "txt"
      local text = M.read_file(f.path)
      if not text or trim(text) == "" then
        mod.problems[#mod.problems + 1] = f.name .. " is empty - add some info to it (see README.txt for the format)."
        return nil
      end
      local ok, data = pcall(mod.format == "json" and Json.decode or parse_txt, text)
      if not ok then
        mod.problems[#mod.problems + 1] = "Couldn't read " .. f.name .. " - " .. tostring(data)
        return nil
      end
      if type(data) ~= "table" or not Json.order[data] then
        mod.problems[#mod.problems + 1] = f.name .. " must contain a JSON object { ... }."
        return nil
      end
      return data
    end
  end
  -- near-miss file names, e.g. "modmabager.json"
  for _, f in ipairs(node.files) do
    local l = lower(f.name)
    if l:match("^modmanager[_%-]log") or l:match("^menu_dump") then
      -- our own log files, not a misspelled manifest
    elseif l:match("^modm.*%.json$") or l:match("^modm.*%.txt$") then
      mod.problems[#mod.problems + 1] = "Found \"" .. f.name .. "\" - rename it to modmanager.json (or modmanager.txt)."
    end
  end
end

local function build(mod, node, cfg, data)
  local known = { name = true, version = true, author = true, description = true, long_description = true,
                  website = true, tags = true, dependencies = true, game_version = true, icon = true, images = true }
  local fields = {}
  local extras = {}
  if data then
    for _, k in ipairs(Json.order[data]) do
      local nk = normkey(k)
      nk = ALIASES[nk] or nk
      local v = data[k]
      if known[nk] then
        if fields[nk] == nil then fields[nk] = v end
      else
        extras[#extras + 1] = { key = (k:gsub("[_%-]+", " ")), value = show(v) }
      end
    end
  end
  mod.name = fields.name and show(fields.name) or node.name
  mod.version = fields.version and show(fields.version) or nil
  mod.author = fields.author and (type(fields.author) == "table" and table.concat(as_list(fields.author), ", ") or show(fields.author)) or nil
  mod.description = fields.description and show(fields.description) or nil
  mod.long_description = fields.long_description and show(fields.long_description) or nil
  mod.website = fields.website and show(fields.website) or nil
  mod.game_version = fields.game_version and show(fields.game_version) or nil
  mod.tags = as_list(fields.tags)
  mod.dependencies = as_list(fields.dependencies)
  mod.extras = extras
  mod.enabled = find_file(node, "enabled.txt") ~= nil

  -- images --------------------------------------------------------------------
  local imgdir = find_dir(node, lower(cfg.IMAGE_FOLDER))
  local on_disk, order = {}, {}
  if imgdir then
    table.sort(imgdir.files, function(a, b) return lower(a.name) < lower(b.name) end)
    for _, f in ipairs(imgdir.files) do
      if IMG_EXT[ext(f.name)] then on_disk[lower(f.name)] = f; order[#order + 1] = lower(f.name) end
    end
  end
  -- sidecar metadata inside the images folder
  local side = {}
  if imgdir then
    for _, sn in ipairs({ "images.json", "metadata.json", "captions.json" }) do
      local sf = find_file(imgdir, sn)
      if sf then
        local text = M.read_file(sf.path)
        if text and trim(text) ~= "" then
          local ok, d = pcall(Json.decode, text)
          if ok then
            for _, e in ipairs(image_entries(d)) do side[lower(basename(e.file))] = e end
          else
            mod.problems[#mod.problems + 1] = "Couldn't read images/" .. sn .. " - " .. tostring(d)
          end
        end
      end
    end
  end

  local images, seen = {}, {}
  local function push(entry)
    local key = lower(basename(entry.file))
    if seen[key] then return end
    seen[key] = true
    local disk = on_disk[key]
    local sc = side[key] or {}
    local img = {
      file = basename(entry.file),
      path = disk and disk.path or nil,
      title = entry.title or sc.title or pretty(basename(entry.file)),
      caption = entry.caption or sc.caption,
      missing = disk == nil,
    }
    if disk then img.w, img.h, img.bytes = read_dims(disk.path) end
    images[#images + 1] = img
  end
  for _, e in ipairs(image_entries(fields.images)) do push(e) end
  for _, key in ipairs(order) do
    -- the icon is shown in the header, not the gallery, unless it is listed explicitly
    if not (fields.icon and lower(basename(show(fields.icon))) == key) then push({ file = on_disk[key].name }) end
  end
  mod.images = images
  if fields.icon then
    local key = lower(basename(show(fields.icon)))
    local disk = on_disk[key]
    if disk then mod.icon = { path = disk.path, file = disk.name } end
  end
end

local function parse_modstxt(text)
  local t = {}
  for line in (text .. "\n"):gmatch("(.-)\r?\n") do
    local n, v = line:match("^%s*([%w_%-%.]+)%s*:%s*(%d)")
    if n then t[lower(n)] = tonumber(v) end
  end
  return t
end

-- Turn a mod on/off the way UE4SS reads it: enabled.txt in the mod folder (and its mods.txt line, if it has one).
-- Takes effect the next time the game starts.
function M.set_enabled(mod, on)
  local ep = mod.path .. "/enabled.txt"
  if on then
    local f, err = io.open(ep, "w")
    if not f then return false, err end
    f:close()
  elseif mod.enabled_file then
    local ok, err = os.remove(ep)
    if not ok then return false, err end
  end
  mod.enabled_file = on
  if mod.modstxt_path and mod.modstxt_state ~= nil then
    local text = M.read_file(mod.modstxt_path)
    if text then
      local out = {}
      for line, eol in text:gmatch("([^\r\n]*)(\r?\n?)") do
        local n = line:match("^%s*([%w_%-%.]+)%s*:%s*%d")
        if n and lower(n) == lower(mod.folder) then
          line = line:gsub("(:%s*)%d", "%1" .. (on and "1" or "0"), 1)
        end
        out[#out + 1] = line .. eol
      end
      local f, err = io.open(mod.modstxt_path, "wb")
      if not f then return false, err end
      f:write(table.concat(out))
      f:close()
    end
    mod.modstxt_state = on and 1 or 0
  end
  mod.enabled = on
  mod.changed = true
  return true
end

-- cfg: the mm_config table. root: node for the Mods folder.
function M.scan(root, cfg, self_folder)
  local mods = {}
  local modstxt, modstxt_path = {}, nil
  local mf = find_file(root, "mods.txt")
  if mf then
    modstxt_path = mf.path
    local text = M.read_file(mf.path)
    if text then modstxt = parse_modstxt(text) end
  end
  for folder, node in pairs(root.dirs) do
    local skip = (cfg.HIDE_SELF and self_folder and lower(folder) == lower(self_folder))
    if not skip and lower(folder) ~= "shared" then
      local mod = { folder = folder, path = node.path, problems = {} }
      local data = read_manifest(mod, node, cfg)
      if data or mod.source or cfg.SHOW_MODS_WITHOUT_MANIFEST then
        build(mod, node, cfg, data)
        mod.has_manifest = data ~= nil
        mod.enabled_file = mod.enabled
        mod.modstxt_path = modstxt_path
        mod.modstxt_state = modstxt[lower(folder)]
        mod.enabled = mod.enabled_file or mod.modstxt_state == 1
        mod.is_self = self_folder ~= nil and lower(folder) == lower(self_folder)
        mods[#mods + 1] = mod
      elseif #mod.problems > 0 then
        build(mod, node, cfg, nil)
        mod.enabled_file = mod.enabled
        mod.modstxt_path = modstxt_path
        mod.modstxt_state = modstxt[lower(folder)]
        mod.enabled = mod.enabled_file or mod.modstxt_state == 1
        mod.is_self = self_folder ~= nil and lower(folder) == lower(self_folder)
        mods[#mods + 1] = mod
      end
    end
  end
  table.sort(mods, function(a, b) return lower(a.name) < lower(b.name) end)
  return mods
end

M.parse_txt = parse_txt
return M
