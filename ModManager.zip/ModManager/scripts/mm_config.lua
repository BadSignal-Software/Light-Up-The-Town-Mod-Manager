-- ModManager settings. Edit freely; restart the game (or press Ctrl+R in the UE4SS console to reload mods).
return {
  -- Mods folder scanning -----------------------------------------------------
  MANIFEST_NAMES = { "modmanager.json", "modmanager.txt" },   -- first one found wins
  IMAGE_FOLDER = "images",
  SHOW_MODS_WITHOUT_MANIFEST = false,   -- true = also list mod folders that have no modmanager file
  HIDE_SELF = false,                    -- true = don't list ModManager itself

  -- Main menu button -----------------------------------------------------------
  BUTTON_LABEL = "mods",
  -- The menu is recognised by any visible text block saying one of these (case-insensitive):
  MENU_MARKER_TEXTS = { "new game" },
  MENU_HOST_CLASS = "W_MainMenu_C",     -- only attach to this menu widget (nil = any); stops it showing on the pause menu
  -- Text of the menu button that gets copied (the "mods" button is a real copy of the game's own button class):
  STYLE_SOURCE_TEXT = "settings",
  BUTTON_TINT_HEX = nil,                -- e.g. "#9992d1" to multiply the copied button graphic by a colour
  BUTTON_SIZE = { w = 300, h = 100 },   -- slate units (1080p space)
  BUTTON_MARGIN = { left = 48, bottom = 36 },
  IDLE_FADE_SECONDS = 4,                -- button fades out after this many idle seconds, returns on mouse move (0 = never fade)
  POLL_MS = 1000,

  -- Keys -----------------------------------------------------------------------
  KEY_TOGGLE = "F8",   -- open/close the manager (only while the main menu is up)
  KEY_DUMP = "F7",     -- writes menu_dump.txt next to main.lua's mod folder (for debugging the menu hookup)

  -- Colours (sRGB hex, sampled from the game's menu) ----------------------------
  PAL = {
    dim = "#0d0816", card = "#2b2340", text = "#f6f1e7", subtle = "#bdb4d3", dark = "#3a3358",
    purple = "#9992d1", lavender = "#d5d8f0", olive = "#c0bd8e", salmon = "#ce9e87",
    sage = "#a3c6a3", sand = "#d2c5b0", flame = "#ffd37a", white = "#ffffff",
  },
}
